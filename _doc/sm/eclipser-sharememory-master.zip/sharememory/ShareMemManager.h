/* 
 * File:   ShareMemManager.h
 * Author: Vicky.H
 * Email:  eclipser@163.com
 *
 * Created on 2014年1月17日, 下午3:16
 */

#ifndef CN_VICKY__SHAREMEMMANAGER_H
#define	CN_VICKY__SHAREMEMMANAGER_H
#include "SMUManager.h"

class User;

extern SMUPool<User> g_UserSMUPool;

#endif	/* CN_VICKY__SHAREMEMMANAGER_H */

