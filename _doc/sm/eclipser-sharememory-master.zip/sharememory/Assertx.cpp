#include "Assertx.h"
#include <time.h>
#include <execinfo.h>

int g_Command_Assert = 0;
//             控制参数，0:会通过弹出对话框让用户选择(缺省值)
//			1:忽略
//			2:继续抛出异常用于获取运行堆栈
int g_Command_IgnoreMessageBox = false; //控制参数，跳过MyMessageBox的中断

void __show__(const char* szTemp) {
    printf("Assert:%s", szTemp);
    throw (1);
}

void __messagebox__(const char*msg) {
    if (g_Command_IgnoreMessageBox)
        return;
}

void __assert__(const char * file, uint line, const char * func, const char * expr) {
    char szTemp[1024] = {0};

    sprintf(szTemp, "[%s][%d][%s][%s]\n", file, line, func, expr);
    __show__(szTemp);
}

void __assertex__(const char * file, uint line, const char * func, const char * expr, const char* msg) {
    char szTemp[1024] = {0};
    sprintf(szTemp, "[%s][%d][%s][%s]\n[%s]\n", file, line, func, expr, msg);
    __show__(szTemp);
}

void __assertspecial__(const char * file, uint line, const char * func, const char * expr, const char* msg) {
    char szTemp[1024] = {0};

    sprintf(szTemp, "S[%s][%d][%s][%s]\n[%s]\n", file, line, func, expr, msg);
    __show__(szTemp);
}

void __protocol_assert__(const char * file, uint line, const char * func, const char * expr) {
    printf("[%s][%d][%s][%s]", file, line, func, expr);
}
