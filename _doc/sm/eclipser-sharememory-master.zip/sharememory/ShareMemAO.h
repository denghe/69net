/* 
 * File:   ShareMemAO.h
 * Author: Vicky.H
 * Email:  eclipser@163.com
 *
 * Created on 2014年1月16日, 下午9:36
 */

#ifndef CN_VICKY__SHAREMEMAO_H
#define	CN_VICKY__SHAREMEMAO_H

#include "ShareMemApi.h"

// 命令模式
enum CMD_MODE {
    CMD_MODE_GETORCRT = 0, //创建或删除
    CMD_MODE_CLEARALL = 1, //清除模式
    CMD_MODE_LOADDUMP = 2, //载入dump模式
};

// 共享内存头结构
struct SMHead {
    SM_KEY m_Key;
    SM_SIZE m_Size;
    uint m_HeadVer; //最后存盘版本

    SMHead() : m_Key(), m_Size(), m_HeadVer() {
    }
};

/*
 * 共享内存访问对象
 * ShareMemory	Access	Object
 */
class ShareMemAO {
public:

    ShareMemAO() : m_pDataPtr(), m_hold(), m_Size(), m_pHeader(), m_CmdArg() {
    }

    ~ShareMemAO() {
    };

    /*
     *	创建ShareMem 访问对象(新创建)
     *  SM_KEY	key		访问键值
     *	SM_SIZE	Size            访问数据区字节个数
     */
    bool Create(SM_KEY key, SM_SIZE size);
    /*
     *	销毁对象
     */
    void Destory();

    /*
     *  附着ShareMem 访问对象(不是新创建)
     *  SM_KEY	key		访问键值
     *	SM_SIZE	size            访问数据区字节个数
     */
    bool Attach(SM_KEY key, SM_SIZE size);

    /*
     *	取消附着(不销毁)
     *  // TODO 尚未实现
     */
    bool Detach();

    /*
     *	获得数据区指针
     */
    void* GetDataPtr() {
        return m_pDataPtr;
    }

    /*
     *	获得 大小为tSize 的第tIndex 个smu的数据
     */
    void* GetTypePtr(SM_SIZE tSize, SM_SIZE tIndex) {
        Assert(tSize > 0);
        Assert(tSize * tIndex < m_Size);
        if (tSize <= 0 || tIndex >= m_Size)
            return NULL;
        return (char*) m_pDataPtr + tSize * tIndex;
    }

    /*
     *	获得数据区总大小
     */
    SM_SIZE GetSize() {
        return m_Size;
    }

    bool DumpToFile(char* FilePath);
    bool MergeFromFile(char* FilePath);

    uint GetHeadVer();
    void SetHeadVer(uint ver);

    //命令
    int m_CmdArg;
private:
    
    SM_SIZE m_Size;             //ShareMemory	内存大小
    void* m_pDataPtr;           // ShareMemory  数据指针
    void* m_pHeader;            // ShareMemory	内存头指针
    SMHandle m_hold;            // ShareMemory	句柄	
};

#endif	/* CN_VICKY__SHAREMEMAO_H */

