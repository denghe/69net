#include "Log.h"
#include "Common.h"
#include <stdarg.h>
#include <string.h>
#include <stdio.h>

// 保证日志记录线程安全
pthread_mutex_t log_mutex;

Log::Log() {
}

Log::~Log() {
}

void Log::SaveLog(const char* filename, const char* msg, ...) {
    __ENTER_FUNCTION

    pthread_mutex_lock(&log_mutex);

    char buffer[2048];
    memset(buffer, 0, 2048);

    va_list argptr;

    try {
        va_start(argptr, msg);
        vsprintf(buffer, msg, argptr);
        va_end(argptr);

        FILE* f = fopen(filename, "ab");
        fwrite(buffer, 1, strlen(buffer), f);
        fclose(f);

        printf(buffer);
    } catch (...) {
        printf("a big error here");
    }

    pthread_mutex_unlock(&log_mutex);
    return;

    __LEAVE_FUNCTION

    pthread_mutex_unlock(&log_mutex);
}