/* 
 * File:   User.h
 * Author: Vicky.H
 * Email:  eclipser@163.com
 *
 * Created on 2014年1月17日, 下午1:32
 */

#ifndef CN_VICKY__USER_H
#define	CN_VICKY__USER_H
#include <stdio.h>

class User {
public:

    User() : username(), password() {
    }
    
    void SetPoolID(uint poolID) {
        m_SMUHead.PoolId = poolID;
    }

    uint GetPoolID() {
        return m_SMUHead.PoolId;
    }
    
    void SetUsername(const char* username) {
        strcpy(this->username, username);
    }
    const char* GetUsername() const {
        return this->username;
    }
    void SetPassword(const char* password) {
        strcpy(this->password, password);
    }
    const char* GetPassword() const {
        return this->password;
    }
private:
    SMUHead m_SMUHead;
    char username[32];
    char password[32];

};

#endif	/* CN_VICKY__USER_H */

