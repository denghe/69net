/* 
 * File:   Assertx.h
 * Author: Vicky.H
 * Email:  eclipser@163.com
 *
 * Created on 2014年1月16日, 下午8:33
 */

// 断言

#ifndef CN_VICKY__ASSERTX_H
#define	CN_VICKY__ASSERTX_H

#include <sys/types.h>
#include <stdio.h>

extern int g_Command_Assert; //控制参数，不提示Assert的对话框，直接忽略
extern int g_Command_IgnoreMessageBox; //控制参数，跳过MyMessageBox的中断

void __assert__(const char* file, uint line, const char* func, const char* expr);
void __assertex__(const char* file, uint line, const char* func, const char* expr, const char* msg);
void __assertspecial__(const char* file, uint line, const char* func, const char* expr, const char* msg);
void __messagebox__(const char* msg);

void __protocol_assert__(const char* file, int line, const char* func, const char* expr);

#define Assert(expr) {if(!(expr)){__assert__(__FILE__,__LINE__,__PRETTY_FUNCTION__,#expr);}}
#define ProtocolAssert(expr) ((VOID)((expr)?0:(__protocol_assert__(__FILE__,__LINE__,__PRETTY_FUNCTION__,#expr),0)))
#define AssertEx(expr,msg) {if(!(expr)){__assertex__(__FILE__,__LINE__,__PRETTY_FUNCTION__,#expr,msg);}}
#define AssertSpecial(expr,msg) {if(!(expr)){__assertspecial__(__FILE__,__LINE__,__PRETTY_FUNCTION__,#expr,msg);}}
#define AssertExPass(expr,msg) {if(!(expr)){__assertex__(__FILE__,__LINE__,__PRETTY_FUNCTION__,#expr,msg);}}
#define MyMessageBox(msg) ((VOID)0)

#endif	/* CN_VICKY__ASSERTX_H */

