/* 
 * File:   Log.h
 * Author: Vicky.H
 * Email:  eclipser@163.com
 *
 * Created on 2014年1月16日, 下午10:45
 */

#ifndef CN_VICKY__LOG_H
#define	CN_VICKY__LOG_H
#include <pthread.h>

#define SHMEM_LOG_PATH "./Log/ShareMemory.log"

extern pthread_mutex_t log_mutex;

class Log {
public:
    Log();
    ~Log();
    //支持异步写入操作的日志写入
    static void SaveLog(const char* filename, const char* msg, ...);
};

#endif	/* CN_VICKY__LOG_H */

