/* 
 * File:   main.cpp
 * Author: Vicky.H
 * Email:  eclipser@163.com
 */
//#include "ShareMemApi.h"
//#include "ShareMemAO.h"
#include "ShareMemManager.h"
#include "User.h"
#include <unistd.h>
#include <iostream>

int g_CmdArgv = CMD_MODE_GETORCRT;
SMUPool<User> g_UserSMUPool;

/*
 * 
 */
int main(void) {
    // 创建内存共享区
//    SM_KEY key = 289997171;
//    SM_SIZE size = 1024 * 1024;
//    SMHandle m_hold = -1;
//    m_hold = ShareMemAPI::CreateShareMem(key, size);
//    if (m_hold == INVALID_SM_HANDLE) {
//        std::cout << "Create ShareMem Error SM_KET = " << key << std::endl;
//        return 1;
//    }

//    使用linux命令查看内存共享的情况
//[vicky@localhost ~]$ ipcs
//
//------ Shared Memory Segments --------
//key        shmid      owner      perms      bytes      nattch     status      shmid 0 这是内存区操作的主键，也就是m_hold的值！！
//0x11490173 0          vicky      666        1048576    0                      // 0x11490173 = 289997171   1048576 = 1024 * 1024
//
//------ Semaphore Arrays --------
//key        semid      owner      perms      nsems     
//
//------ Message Queues --------
//key        msqid      owner      perms      used-bytes   messages  
    
//    取得ipc信息：
//ipcs [-m|-q|-s]
//-m 输出有关共享内存(shared memory)的信息
//-q 输出有关信息队列(message queue)的信息
//-s 输出有关“遮断器”(semaphore)的信息
//%ipcs -m
    
//    删除ipc
//ipcrm -m|-q|-s shm_id
//ipcrm -m 0   0对应 shmid 也就是m_hold的值
    
    // 程序删除共享内存
//    ShareMemAPI::CloseShareMem(m_hold);
    
    // 操作共享内存区
//    void* pMemHead = 0;
//    pMemHead = ShareMemAPI::MapShareMem(m_hold);
//    std::cout << std::showpoint << pMemHead << std::endl;
//    strcpy((char*) pMemHead, "hello share memory");
//    std::cout << "pMemHead : " << (char*)pMemHead << std::endl;
//    
//    int result = ShareMemAPI::UnMapShareMem(pMemHead);
//    std::cout << "result = " << result << std::endl;
//    std::cout << std::showpoint << pMemHead << std::endl;
    
    // 在创建共享内存区，并且操作了共享内存区之后，新进程访问共享内存区
    // handle = 262144 ,key = 289997171 ,error: 0 
//    SMHandle m_hold = -1;
//    m_hold = ShareMemAPI::OpenShareMem(289997171, 1024 * 1024);
//    void* pMemHead = 0;
//    pMemHead = ShareMemAPI::MapShareMem(m_hold);
//    std::cout << "pMemHead : " << (char*)pMemHead << std::endl;
#define USERKEY 10001
    std::cout << &g_UserSMUPool << std::endl;
    
    std::cout << "\n---------------------------" << std::endl;
    bool flag;
    flag = g_UserSMUPool.Init(10, USERKEY, SMPT_SHAREMEM);
    if (flag) {
        std::cout << "初始化共享内存池成功！" << std::endl;
    } else{
        std::cout << "初始化共享内存池失败！" << std::endl;
    }
    
    pid_t pid;
    pid = fork();
    if (pid == 0) { // 子进程
        std::cout << "\n---------------------------" << std::endl;
        //    写入数据
        User* pUser1 = g_UserSMUPool.NewObj();
        if (pUser1) {
            std::cout << pUser1->GetPoolID() << std::endl;
        }
        User* pUser2 = g_UserSMUPool.NewObj();
        if (pUser2) {
            std::cout << pUser2->GetPoolID() << std::endl;
        }
        pUser1->SetUsername("u1");
        pUser1->SetPassword("p1");

        pUser2->SetUsername("u2");
        pUser2->SetPassword("p2");
    } else if (pid > 0) { // 父进程
        std::cout << "\n---------------------------" << std::endl;
        sleep(5);
         // 读取数据
        User* pUser1 = g_UserSMUPool.GetPoolObj(0);
        User* pUser2 = g_UserSMUPool.GetPoolObj(1);
        std::cout << "\n---------------------------" << std::endl;
        if (pUser1) {
            std::cout << pUser1->GetUsername() << " " << pUser1->GetPassword() << std::endl;
        }
        if (pUser2) {
            std::cout << pUser2->GetUsername() << " " << pUser2->GetPassword() << std::endl;
        }
    }
    
    // 删除共享内存区
    g_UserSMUPool.Finalize();
    
    return 0;
}
